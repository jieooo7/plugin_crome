package com.subway.controller;

import com.jfinal.aop.Before;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.ext.interceptor.POST;
import com.subway.model.BaseModel;
import com.subway.model.dataModel.MemberIdModel;
import com.subway.service.FeedbackService;
import com.subway.validator.MemberIdValidator;
import com.subway.validator.QuestionValidator;

/**
 * Created by thy on 17-5-16.
 */
public class FeedbackController extends Controller{


    BaseModel<MemberIdModel> baseModel = new BaseModel<MemberIdModel>();

    @Before({POST.class,MemberIdValidator.class, QuestionValidator.class})//问题不为空验证
    @ActionKey("api/add_feedback")
    public BaseModel addPassenger() {

        BaseModel<MemberIdModel> baseModel = new BaseModel<MemberIdModel>();

        String member_id = getAttr("member_id");
        String question = getAttr("question");

        FeedbackService.me.addFeedback(member_id,question,baseModel);

        return baseModel;
    }

}
