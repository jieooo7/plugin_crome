package com.subway.controller;

import com.jfinal.aop.Before;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.ext.interceptor.POST;
import com.jfinal.kit.StrKit;
import com.subway.model.BaseModel;
import com.subway.model.dataModel.ChargeModel;
import com.subway.model.dataModel.ChargeOrderModel;
import com.subway.model.dataModel.PrepayModel;
import com.subway.service.ChargeService;
import com.subway.util.OrderNoGenerate;
import com.subway.validator.FeeValidator;
import com.subway.validator.MemberIdValidator;
import com.subway.validator.OrderNoValidator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.math.BigDecimal;

/**
 * Created by thy on 17-4-27.
 */
public class ChargeController extends Controller {
    private static final transient Logger log = LogManager.getLogger(ChargeController.class);

    @Before({POST.class, FeeValidator.class})
    @ActionKey("api/recharge")
    public BaseModel recharge() {

        BaseModel<ChargeModel> baseModel = new BaseModel<ChargeModel>();

        String member_id = getAttr("member_id");
        String fee = getAttr("fee");
        String prePayId = getAttr("prePayId");
        String order_no = getAttr("order_no");
        String payType = getAttr("payType");
        //此处负责update订单状态
        ChargeService.me.updateCharge(member_id,new BigDecimal(fee),prePayId,order_no,payType,baseModel);
        return baseModel;
    }


    @Before({POST.class, MemberIdValidator.class, OrderNoValidator.class})
    @ActionKey("api/query_recharge")
    public BaseModel queryRecharge() {

        BaseModel<ChargeOrderModel> baseModel = new BaseModel<ChargeOrderModel>();

        String member_id = getAttr("member_id");
        String order_no = getAttr("order_no");//转换成double

        ChargeService.me.queryCharge(member_id,order_no,baseModel);
        return baseModel;
    }

    @Before({POST.class, MemberIdValidator.class})
    @ActionKey("api/get_pre_pay")
    public BaseModel getPrepay() {
        //生成预付单号后写入数据库，预付单号+订单号 对应关系

        BaseModel<PrepayModel> baseModel = new BaseModel<PrepayModel>();
        String payType="20";
        String member_id = getAttr("member_id");
        String bodyStr = getAttr("body");//转换成double
        int fee = getAttr("fee");
        String ip = getAttr("ip");
        String openID = getAttr("openID");
        String order_no = OrderNoGenerate.generate(payType);
//        Map<String,String> map=wxpay(bodyStr,fee,order_no,ip,openID);
        if(!StrKit.isBlank(openID)){
            //插入数据库,返回prepay
            ChargeService.me.charge(member_id,fee,order_no,bodyStr,ip,openID,payType,baseModel);
        }

        return baseModel;
    }




}
