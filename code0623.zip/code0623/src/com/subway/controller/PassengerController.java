package com.subway.controller;

import com.jfinal.aop.Before;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.ext.interceptor.POST;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;
import com.subway.model.dataModel.ListModel;
import com.subway.model.dataModel.MemberIdModel;
import com.subway.model.dataModel.PassengerModel;
import com.subway.service.PassengerSevice;
import com.subway.validator.IdCardValidator;
import com.subway.validator.MemberIdValidator;
import com.subway.validator.NameValidator;
import com.subway.validator.TelValidator;

import java.util.List;

/**
 * Created by thy on 17-4-26.
 */
public class PassengerController extends Controller {

    @Before({POST.class,MemberIdValidator.class, TelValidator.class, NameValidator.class, IdCardValidator.class})
    @ActionKey("api/add_passenger")
    public BaseModel addPassenger() {

        BaseModel<MemberIdModel> baseModel = new BaseModel<MemberIdModel>();

        String cellphone = getAttr("cellphone");
        String member_id = getAttr("member_id");
        String real_name = getAttr("real_name");
        String id_card = getAttr("id_card");

        int result= PassengerSevice.me.addPassenger(member_id,cellphone,real_name,id_card);

        if (-1==result) {
            baseModel.setError(ErrorCode.REAL_NAME_FAIL);
            return baseModel;
        }

        baseModel.setData(new MemberIdModel(result));

        return baseModel;
    }


    @Before({POST.class,MemberIdValidator.class})
    @ActionKey("api/passengers")
    public BaseModel passengers() {

        BaseModel<ListModel<PassengerModel> > baseModel = new BaseModel<ListModel<PassengerModel> >();

        String member_id = getAttr("member_id");

        List<PassengerModel> result= PassengerSevice.me.passengers(member_id);

        if (null==result) {
            baseModel.setError(ErrorCode.NO_DATA);
//            baseModel.setMsg(ErrorCode.getErrorMsg(ErrorCode.NO_DATA));
            return baseModel;
        }

        baseModel.setData(new ListModel(result));

        return baseModel;
    }

    @Before({POST.class,MemberIdValidator.class, NameValidator.class, IdCardValidator.class})
    @ActionKey("api/real_name")
    public BaseModel realName() {

        BaseModel baseModel = new BaseModel();

        String cellphone = getAttr("cellphone");
        String member_id = getAttr("member_id");
        String real_name = getAttr("real_name");
        String id_card = getAttr("id_card");


        int result= PassengerSevice.me.realName(member_id,cellphone,real_name,id_card);

        if (-1==result) {
            baseModel.setStatus(ErrorCode.REAL_NAME_FAIL);
            baseModel.setMsg(ErrorCode.getErrorMsg(ErrorCode.REAL_NAME_FAIL));
            return baseModel;
        }



        return baseModel;
    }
}
