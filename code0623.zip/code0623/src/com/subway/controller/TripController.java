package com.subway.controller;

import com.jfinal.aop.Before;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.ext.interceptor.POST;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;
import com.subway.model.dataModel.QueryTripOrderModel;
import com.subway.model.dataModel.QueryTripOrderOverModel;
import com.subway.model.dataModel.TripOrderModel;
import com.subway.service.TripService;
import com.subway.validator.MemberIdValidator;
import com.subway.validator.OrderNoValidator;

/**
 * Created by thy on 17-4-27.
 */
public class TripController extends Controller{


    @Before({POST.class, MemberIdValidator.class})
    @ActionKey("api/trip_order")
    public BaseModel tripOrder() {

        BaseModel<TripOrderModel> baseModel = new BaseModel<TripOrderModel>();

        String member_id = getAttr("member_id");
        String passengers = getAttr("passengers");//转换成double
        String start = getAttr("start_station_id");

        if(passengers.isEmpty()){
            baseModel.setStatus(ErrorCode.NO_PASSENGERS);
            baseModel.setMsg(ErrorCode.getErrorMsg(ErrorCode.NO_PASSENGERS));
            return baseModel;

        }
        if(start.isEmpty()){
            baseModel.setStatus(ErrorCode.NO_START_STATION_ID);
            baseModel.setMsg(ErrorCode.getErrorMsg(ErrorCode.NO_START_STATION_ID));
            return baseModel;

        }

        TripService.me.tripOrder(member_id,passengers,start,baseModel);
        return baseModel;
    }

    @Before({POST.class, MemberIdValidator.class, OrderNoValidator.class})
    @ActionKey("api/query_trip_order")
    public BaseModel queryTripOrder() {

        BaseModel<QueryTripOrderModel> baseModel = new BaseModel<QueryTripOrderModel>();

        String member_id = getAttr("member_id");
        String order_no = getAttr("order_no");

        TripService.me.queryTripOrder(member_id,order_no,baseModel);
        return baseModel;
    }


    @Before({POST.class, MemberIdValidator.class, OrderNoValidator.class})
    @ActionKey("api/trip_order_over")
    public BaseModel TripOrderOver() {

        BaseModel<TripOrderModel> baseModel = new BaseModel<TripOrderModel>();

        String member_id = getAttr("member_id");
        String order_no = getAttr("order_no");

        TripService.me.tripOrderOver(member_id,order_no,baseModel);
        return baseModel;
    }


    @Before({POST.class, MemberIdValidator.class, OrderNoValidator.class})
    @ActionKey("api/query_trip_order_over")
    public BaseModel queryTripOrderOver() {

        BaseModel<QueryTripOrderOverModel> baseModel = new BaseModel<QueryTripOrderOverModel>();

        String member_id = getAttr("member_id");
        String order_no = getAttr("order_no");

        TripService.me.queryTripOrderOver(member_id,order_no,baseModel);
        return baseModel;
    }

}
