package com.subway.controller;

import com.jfinal.aop.Before;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.ext.interceptor.POST;
import com.subway.model.BaseModel;
import com.subway.model.dataModel.BalanceModel;
import com.subway.model.dataModel.UserInfoModel;
import com.subway.service.UserInfoService;
import com.subway.validator.MemberIdValidator;

/**
 * Created by thy on 17-4-27.
 */
public class UserInfoController extends Controller {

    @Before({POST.class,MemberIdValidator.class})
    @ActionKey("api/member_info")
    public BaseModel getUserInfo() {

        BaseModel<UserInfoModel> baseModel = new BaseModel<UserInfoModel>();

        String member_id = getAttr("member_id");

        UserInfoService.me.getUserInfo(member_id,baseModel);

        return baseModel;
    }


    @Before({POST.class,MemberIdValidator.class})
    @ActionKey("api/balance")
    public BaseModel getBalance() {

        BaseModel<BalanceModel> baseModel = new BaseModel<BalanceModel>();

        String member_id = getAttr("member_id");

        UserInfoService.me.getBalance(member_id,baseModel);

        return baseModel;
    }
}
