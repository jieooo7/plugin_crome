package com.subway.controller;

import com.jfinal.aop.Before;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.ext.interceptor.POST;
import com.jfinal.kit.StrKit;
import com.jfinal.plugin.redis.Redis;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;
import com.subway.model.dataModel.MemberIdModel;
import com.subway.service.UserService;
import com.subway.util.OrderNoGenerate;
import com.subway.validator.CodeValidator;
import com.subway.validator.PassWordValidator;
import com.subway.validator.TelValidator;
import okhttp3.*;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by thy on 17-4-20.
 */

public class UserController extends Controller {

    private static final transient Logger log = LogManager.getLogger(UserController.class);
    //    Before 注解用来对拦截器进行配置
//    @Before(Restful.class)
    @Before({POST.class, TelValidator.class, CodeValidator.class})
    @ActionKey("api/login")
    public BaseModel login() {
	
        return common(1);
    }

    @Before({POST.class, TelValidator.class, CodeValidator.class})
    @ActionKey("api/register")
    public BaseModel register() {

        return common(2);
    }

    @Before({POST.class, TelValidator.class, CodeValidator.class, PassWordValidator.class})
    @ActionKey("api/update")
    public BaseModel update() {

        return common(3);
    }

    @Before({POST.class, TelValidator.class})
    @ActionKey("api/get_sms")
    public BaseModel sendCode() throws IOException {
//发送短信一个方法，判断频繁请求另一个
        String code = OrderNoGenerate.smscodeGenerate();
        String tel = getAttr("cellphone");
        String format = "验证码：{%s}，30分钟内有效。欢迎您乘坐厦门地铁。";
        return sendPass(format, tel, code, code);

    }

    public BaseModel sendPass(String format, String tel, String code, String... para) {

        BaseModel model = new BaseModel();

        com.jfinal.plugin.redis.Cache cache = Redis.use("master");
        SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
        String day = dateformat.format(new Date());


        String dayCountKey = tel + "_count_" + day;
        String lastSendKey = tel + "_send";
//        int count = Integer.parseInt("" + cache.get(dayCountKey));

        String dayCountValue = ""+cache.get(dayCountKey);
        int count = 0;
        if (!StrKit.isBlank(dayCountValue)) {
            count = Integer.parseInt("" + cache.get(dayCountKey));
        }

        int lastSend = 0;
        if (cache.get(lastSendKey) == null) {
            lastSend = 0;
        } else {

            lastSend = Integer.parseInt("" + cache.get(lastSendKey));
        }

        if (cache.get(dayCountKey) != null && count > 10 || lastSend > 3) {

            model.setMsg(ErrorCode.TOO_MORE_SMS);
            model.setMsg(ErrorCode.getErrorMsg(ErrorCode.TOO_MORE_SMS));
            return model;

        }


        if (sendSms(format, tel, code, para)) {

            if (!StrKit.isBlank(code)) {

                cache.setex(tel, 1800, code);
            }

            cache.setex(dayCountKey, 60 * 60 * 24, ++count);
            cache.setex(lastSendKey, 300, ++lastSend);
            return model;
        }
        model.setStatus(ErrorCode.NO_SMS);
        model.setMsg(ErrorCode.getErrorMsg(ErrorCode.NO_SMS));
        return model;
    }


    public boolean sendSms(String format, String tel, String code, String... para) {


        String url = "https://sms.253.com/msg/send";//应用地址
        String un = "N3662481";//账号
        String pw = "KOiuvPJNAx5c40";//密码
        String msg = "";

        String rd = "0";//产品ID
        String ex = "";//扩展码
        msg = String.format(format, para);

        OkHttpClient client = new OkHttpClient();
        FormBody.Builder builder = new FormBody.Builder();
        builder.add("un", un);
        builder.add("pw", pw);
        builder.add("phone", tel);
        builder.add("msg", msg);
        builder.add("rd", rd);
        builder.add("ex", ex);
        RequestBody body = builder.build();

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String resBody = response.body().string();
                String resCode = resBody.split("\n")[0].split(",")[1];
                if ("0".equals(resCode)) {
                    return true;
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }


    public BaseModel common(int type) {
        BaseModel<MemberIdModel> baseModel = new BaseModel<MemberIdModel>();

        String cellphone = getAttr("cellphone");
        String password = "";
        password = getAttr("password");


        int result = -1;
        if (StrKit.isBlank(password)) {
            com.jfinal.plugin.redis.Cache cache = Redis.use("master");
            String smscode = cache.get(cellphone);


            if (StrKit.isBlank(smscode) || !smscode.equals(getAttr("ver_code"))) {
                baseModel.setStatus(ErrorCode.INVALID_VERCODE);
                baseModel.setMsg(ErrorCode.getErrorMsg(ErrorCode.INVALID_VERCODE));
                return baseModel;
            } else {

                //验证码登录处理

                switch (type) {

                    case 1:

                        String randomCode = OrderNoGenerate.smscodeGenerate();
                        result = UserService.me.register(cellphone, randomCode);
                        //发送密码给用户

                        String msg = "欢迎您成为厦门地铁新用户，账号：{%s}  初始密码：{%s} 请您尽快登录平台进行修改并完善其他资料。";

                        sendSms(msg, cellphone, "", cellphone, randomCode);

                        break;

                    case 2:
                        //返回提示密码为空
                        baseModel.setStatus(ErrorCode.NO_PASS);
                        baseModel.setMsg(ErrorCode.getErrorMsg(ErrorCode.NO_PASS));
                        return baseModel;

                    case 3:
                        String new_password = getAttr("new_password");
                        result = UserService.me.changePasswordBySms(cellphone, new_password);
                        break;

                }
            }

        } else {

            switch (type) {

                case 1:
                    result = UserService.me.login(cellphone, password);
                    break;

                case 2:
                    com.jfinal.plugin.redis.Cache cache = Redis.use("master");
                    String smscode = cache.get(cellphone);
                    if (StrKit.isBlank(smscode) || !smscode.equals(getAttr("ver_code"))) {
                        baseModel.setStatus(ErrorCode.INVALID_VERCODE);
                        baseModel.setMsg(ErrorCode.getErrorMsg(ErrorCode.INVALID_VERCODE));
                        return baseModel;
                    }
                    result = UserService.me.register(cellphone, password);
                    break;

                case 3:
                    String new_password = getAttr("new_password");
                    result = UserService.me.changePassword(cellphone, password, new_password);
                    break;

            }
        }


        if (-1 == result) {
            log.warn(cellphone+"密码错误");
            baseModel.setStatus(ErrorCode.ERROR_PASS);
            baseModel.setMsg(ErrorCode.getErrorMsg(ErrorCode.ERROR_PASS));
            return baseModel;
        }

        if (-2 == result) {
            log.warn(cellphone+"手机号已经注册");
            baseModel.setStatus(ErrorCode.HAVE_TEL);
            baseModel.setMsg(ErrorCode.getErrorMsg(ErrorCode.HAVE_TEL));
            return baseModel;
        }

        baseModel.setData(new MemberIdModel(result));

        return baseModel;
    }


    @ActionKey("api/invalid")
    public void invalid() {

        BaseModel model = new BaseModel();

        renderJson(model);
    }
}