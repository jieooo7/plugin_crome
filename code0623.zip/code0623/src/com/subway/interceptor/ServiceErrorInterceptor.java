package com.subway.interceptor;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-4-28.
 */
public class ServiceErrorInterceptor implements Interceptor {
    @Override
    public void intercept(Invocation inv) {
        if (inv.getArg(0) != null) {
            inv.invoke();
        } else {
            ((BaseModel)inv.getArg(1)).setStatus(ErrorCode.NO_DATA);
            ((BaseModel)inv.getArg(1)).setMsg(ErrorCode.getErrorMsg(ErrorCode.NO_DATA));
//也可以添加第三个参数，设置错误类型
        }
    }
}
