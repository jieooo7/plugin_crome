package com.subway.interceptor;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;
import com.jfinal.kit.JsonKit;
import com.jfinal.kit.StrKit;
import com.subway.config.constant.ErrorCode;
import com.subway.config.constant.ParaName;
import com.subway.config.constant.SecurityCode;
import com.subway.model.BaseModel;
import com.subway.model.UnsignModel;
import com.subway.util.AES;
import com.subway.util.MD5;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by thy on 17-4-24.
 */
public class GlobalInterceptor implements Interceptor {

//    private static final Set<String> excludedActionKeys = new HashSet<String>();
//    static {
////        excludedActionKeys.add("/wx/notify");
////        excludedActionKeys.add("/wx/config");
////        excludedActionKeys.add("/wx/getCode");
//    }

//    public static void addExcludedActionKey(String actionKey) {
//        excludedActionKeys.add(actionKey);
//    }

    public void intercept(Invocation inv) {

//        if (excludedActionKeys.contains(inv.getActionKey())) {
//
//            // 这里写拦截器相应的处理逻辑
//            inv.invoke();
//            return;
//        }
        System.out.println("Before method invoking");


        Controller control = inv.getController();
        String cipherText = control.getPara(ParaName.REQ_PARA);



        if (StrKit.isBlank(cipherText)) {
            BaseModel model = new BaseModel();
            model.setStatus(ErrorCode.NO_REQ);
            model.setMsg(ErrorCode.getErrorMsg(ErrorCode.NO_REQ));
            model.setSign(MD5.getMD5(JsonKit.toJson(model.getData())));
            control.renderJson(model);
            return;
        }
        if (!match(control, cipherText)) {

//            try {
//                control.forwardAction("invalid");重定向操作需要到handler中处理，拦截器处理不了
//                control.getResponse().sendRedirect("api/invalid");
//            } catch (IOException e) {
//                e.printStackTrace();
//                control.getResponse().setStatus(HttpStatusCode.REDIRECT);//设置302重定向
//            control.renderError(302);
//            }

            BaseModel model = new BaseModel();
            model.setStatus(ErrorCode.SIGN_ERROR);
            model.setMsg(ErrorCode.getErrorMsg(ErrorCode.SIGN_ERROR));
            model.setSign(MD5.getMD5(JsonKit.toJson(model.getData())));
            control.renderJson(model);
            return;


        }


        inv.invoke();

        afterInvoke(control, (BaseModel<?>) inv.getReturnValue());


        System.out.println("After method invoking");
    }

    public boolean match(Controller control, String cipherText) {

        String raw = null;
        try {

            raw = AES.desEncrypt(cipherText, SecurityCode.AES_Key).trim();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (raw == null) {
            return false;
        }
        Map<String, Object> map = urlParamsToMap(raw);
        String sign = raw.substring(raw.indexOf("&sign=") + 6);
        String unSigned = raw.substring(0, raw.indexOf("&sign="));


        if (sign.equalsIgnoreCase(MD5.getMD5(unSigned))) {
            control.setAttrs(map);
            return true;
        }
        return false;
    }


    public void afterInvoke(Controller control, BaseModel<?> model) {
//            String unSign="status="+model.getStatus()+"&data="+JsonKit.toJson(model.getData())+"&msg="+model.getMsg();
        UnsignModel unsignModel = new UnsignModel();
        unsignModel.setStatus(model.getStatus());
        unsignModel.setData(model.getData());
        unsignModel.setMsg(model.getMsg());
        String unSign = JsonKit.toJson(unsignModel);
        System.out.println("未签名：" + unSign);
        model.setSign(MD5.getMD5(unSign));
        control.renderJson(model);
    }


    public static Map<String, Object> urlParamsToMap(String param) {
        Map<String, Object> map = new HashMap<String, Object>(0);
        if (param.isEmpty()) {
            return map;
        }
        String[] params = param.split("&");
        for (int i = 0; i < params.length; i++) {
            String[] p = params[i].split("=");
            if (p.length == 2) {
                map.put(p[0], p[1]);
            }
        }
        return map;
    }


    public static void main(String[] args) {
        String text = "cellphone=15116998567&password=123456&sign=8a802cbd4dee71dd74347e3c8e5f58d8";
        System.out.println(text.substring(text.indexOf("&sign=") + 6));
        System.out.println(text.substring(0, text.indexOf("&sign=")));
    }


}
