package com.subway.wx_pay;

import java.util.List;

/**
 * Created by thy on 17-5-5.
 */
public class Model {
    private String Url;
    private String ToUserName;
    private String FromUserName;
    private String CreateTime;
    private String MsgType;
    private String ArticleCount;

    private List<SubModel> Articles;

    public String getUrl() {
        return Url;
    }

    public void setUrl(String url) {
        Url = url;
    }

    public String getToUserName() {
        return ToUserName;
    }

    public void setToUserName(String toUserName) {
        ToUserName = toUserName;
    }

    public String getFromUserName() {
        return FromUserName;
    }

    public void setFromUserName(String fromUserName) {
        FromUserName = fromUserName;
    }

    public String getCreateTime() {
        return CreateTime;
    }

    public void setCreateTime(String createTime) {
        CreateTime = createTime;
    }

    public String getMsgType() {
        return MsgType;
    }

    public void setMsgType(String msgType) {
        MsgType = msgType;
    }

    public String getArticleCount() {
        return ArticleCount;
    }

    public void setArticleCount(String articleCount) {
        ArticleCount = articleCount;
    }

    public List<SubModel> getArticles() {
        return Articles;
    }

    public void setArticles(List<SubModel> articles) {
        Articles = articles;
    }
}
