package com.subway.wx_pay;


import com.subway.wx_pay.util.XmlUtil;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class Main {
	private static final transient Logger log = Logger.getLogger(Main.class);

	public static void main(String[] args) {

		log.debug("start");
		try {


			String xml = "<xml>\n" +
					"<ToUserName><![CDATA[toUser]]></ToUserName>\n" +
					"<FromUserName><![CDATA[fromUser]]></FromUserName>\n" +
					"<CreateTime>12345678</CreateTime>\n" +
					"<MsgType><![CDATA[news]]></MsgType>\n" +
					"<ArticleCount>2</ArticleCount>\n" +
					"<Articles>\n" +
					"<item>\n" +
					"<Title><![CDATA[title1]]></Title> \n" +
					"<Description><![CDATA[description1]]></Description>\n" +
					"<PicUrl><![CDATA[picurl]]></PicUrl>\n" +
					"<Url><![CDATA[url]]></Url>\n" +
					"</item>\n" +
					"<item>\n" +
					"<Title><![CDATA[title]]></Title>\n" +
					"<Description><![CDATA[description]]></Description>\n" +
					"<PicUrl><![CDATA[picurl]]></PicUrl>\n" +
					"<Url><![CDATA[urldddd]]></Url>\n" +
					"</item>\n" +
					"</Articles>\n" +
					"</xml> ";
			Model fromModel = (Model) XmlUtil.getObjectFromXML(xml, new Model().getClass());
			System.out.println(fromModel.getArticles().get(1).getUrl());


			List<SubModel> articles = new ArrayList<SubModel>();
			SubModel subModel = null;
			for (int i = 0; i < 4; i++) {
				subModel = new SubModel();
				subModel.setDescription("des");
				subModel.setPicUrl("picurl");
				subModel.setTitle("title");
				subModel.setUrl("url");
				articles.add(subModel);
			}
			Model model = new Model();
			model.setArticleCount("count");
			model.setArticles(articles);
			model.setCreateTime("time");
			model.setFromUserName("user");
			model.setMsgType("type");
			model.setUrl("http");
//
			XmlUtil.xstream.alias("xml", model.getClass());
			XmlUtil.xstream.alias("item", subModel.getClass());

			System.out.println(XmlUtil.xstream.toXML(model));
//            System.out.println(new Gson().toJson(model));


			//--------------------------------------------------------------------
			//温馨提示，第一次使用该SDK时请到com.tencent.common.Configure类里面进行配置
			//--------------------------------------------------------------------


			//--------------------------------------------------------------------
			//PART One:基础组件测试
			//--------------------------------------------------------------------

			//1）https请求可用性测试
			//HTTPSPostRquestWithCert.test();

			//2）测试项目用到的XStream组件，本项目利用这个组件将Java对象转换成XML数据Post给API
			//XStreamTest.test();


			//--------------------------------------------------------------------
			//PART Two:基础服务测试
			//--------------------------------------------------------------------

			//1）测试被扫支付API
			//PayServiceTest.test();

			//2）测试被扫订单查询API
			//PayQueryServiceTest.test();

			//3）测试撤销API
			//温馨提示，测试支付API成功扣到钱之后，可以通过调用PayQueryServiceTest.test()，将支付成功返回的transaction_id和out_trade_no数据贴进去，完成撤销工作，把钱退回来 ^_^v
			//ReverseServiceTest.test();

			//4）测试退款申请API
			//RefundServiceTest.test();

			//5）测试退款查询API
			//RefundQueryServiceTest.test();

			//6）测试对账单API
			//DownloadBillServiceTest.test();


			//本地通过xml进行API数据模拟的时候，先按需手动修改xml各个节点的值，然后通过以下方法对这个新的xml数据进行签名得到一串合法的签名，最后把这串签名放到这个xml里面的sign字段里，这样进行模拟的时候就可以通过签名验证了
			// XmlUtil.log(Signature.getSignFromResponseString(XmlUtil.getLocalXMLString("/test/com/tencent/business/refundqueryserviceresponsedata/refundquerysuccess2.xml")));

			//XmlUtil.log(new Date().getTime());
			//XmlUtil.log(System.currentTimeMillis());

		} catch (Exception e) {
		}

	}

}
