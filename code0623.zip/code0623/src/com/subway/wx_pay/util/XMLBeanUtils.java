package com.subway.wx_pay.util;

import java.util.Map;

/**
 * Created by thy on 17-5-3.
 * map生成xml
 */
public class XMLBeanUtils {

    public static String map2XmlString(Map<String, Object> map) {
        String xmlResult = "";

        StringBuffer sb = new StringBuffer();
        sb.append("<xml>");
        for (String key : map.keySet()) {
            System.out.println(key + "========" + map.get(key));

            String value = "<![CDATA[" + map.get(key) + "]]>";
            sb.append("<" + key + ">" + value + "</" + key + ">");
            System.out.println();
        }
        sb.append("</xml>");
        xmlResult = sb.toString();

        return xmlResult;
    }

}
