package com.subway.wx_pay.util;

/**
 * Created by thy on 17-5-19.
 */
public class WxConstant {

    public static final String WX_KEY="aa9bc9ce3b0de95e059f85e52e56765D";
    public static final String APPID="wxe1904df24ebf4cbe";
    public static final String MCH_ID="1453975202";
    public static final String MD5="MD5";
    public static final String CNY="CNY";
    public static final String JSAPI="JSAPI";
    public static final String WX_NOTIFY="http://test.qhtpay.cn/wx/notify";
}
