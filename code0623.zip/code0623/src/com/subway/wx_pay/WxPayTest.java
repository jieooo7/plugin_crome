package com.subway.wx_pay;

import com.google.gson.Gson;
import com.subway.util.OrderNoGenerate;
import com.subway.wx_pay.model.request.ReqOrderModel;
import com.subway.wx_pay.model.response.TokenModel;
import com.subway.wx_pay.util.RandomStringGenerator;
import com.subway.wx_pay.util.Signature;
import com.subway.wx_pay.util.XMLBeanUtils;
import com.subway.wx_pay.util.XMLParser;
import okhttp3.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;

/**
 * Created by thy on 17-5-3.
 */
public class WxPayTest {

    public void wxpay() {
        String url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
        ReqOrderModel model = new ReqOrderModel();

        model.setNonce_str(RandomStringGenerator.getRandomStringByLength(30));
        model.setBody("sss-ssss");
        model.setOut_trade_no(OrderNoGenerate.generate("wx"));
        model.setTotal_fee(1000);
        model.setSpbill_create_ip("123.12.12.123");
        model.setNotify_url("http://test.qhtpay.cn/wx/notify");
        model.setOpenid("ozBT6wHgomDqzOAkcKcKEa8ohuAs");

        try {
            model.setSign(Signature.getSign(model));
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        System.out.println("" + model.toMap());

        String requestBody = XMLBeanUtils.map2XmlString(model.toMap());
        String responseXml = "";
        MediaType XML = MediaType.parse("application/xml; charset=utf-8");
        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(XML, requestBody);
        System.out.println("" + requestBody);

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                responseXml = response.body().string();
                System.out.println(responseXml);
                try {
                    Map<String, Object> map = XMLParser.getMapFromXML(responseXml);
                    if (map.get("return_code").toString().equals("SUCCESS") && map.get("result_code").toString().equals("SUCCESS")) {
                        if (Signature.checkIsSignValidFromResponseString(responseXml)) {

                            System.out.println("返回============" + map.get("prepay_id"));

                        }
                    }
                } catch (ParserConfigurationException e) {
                    e.printStackTrace();
                } catch (SAXException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }


    public void getToken() {

        String url = "https://api.weixin.qq.com/cgi-bin/token?";
        String appid = "wxe1904df24ebf4cbe";
        String secret = "67e5d1e7e8b9c68657026ed814f214d6";

        String requestBody = "grant_type=client_credential&" + "appid=" + appid + "&secret=" + secret;
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url + requestBody)
                .build();
        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String body = response.body().string();
//                string()不能多次调用
//                jfinal 3.0默认 json 实现暂不支持 json 到 object 的转换
                System.out.println("返回============" + body);
                Gson gson = new Gson();

                TokenModel tokenModel = gson.fromJson(body, TokenModel.class);
                System.out.println("返回============" + tokenModel.getAccess_token());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getOpenId() {
        String appid = "wxe1904df24ebf4cbe";
        String secret = "67e5d1e7e8b9c68657026ed814f214d6";
        String url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxe1904df24ebf4cbe&redirect_uri=http%3a%2f%2ftest.qhtpay.cn%2fwx%2fgetCode&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";

    }


    public void sms() throws UnsupportedEncodingException {
        String url = "https://sms.253.com/msg/send";//应用地址
        String un = "N3662481";//账号
        String pw = "KOiuvPJNAx5c40";//密码
        String phone = "18250799741";//手机号码，多个号码使用","分割
        String msg = "给你发条测试短信，现在做什么呢--from Lee";//短信内容
        String rd = "0";//产品ID
        String ex = "";//扩展码

        OkHttpClient client = new OkHttpClient();
        FormBody.Builder builder = new FormBody.Builder();
        builder.add("un", un);
        builder.add("pw", pw);
        builder.add("phone", phone);
        builder.add("msg", msg);
        builder.add("rd", rd);
        builder.add("ex", ex);
        RequestBody body = builder.build();

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try {
            Response response = client.newCall(request).execute();
            System.out.println("返回：" + response.body().string());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws IOException, SAXException, ParserConfigurationException {
        WxPayTest test = new WxPayTest();
//        test.sms();

//        test.wxpay();
//        test.getToken();

//        String res="20161025170822,0\n" +
//                "16102517082223817";
//        System.out.println("返回："+res.split("\n")[0].split(",")[1]);
//        System.out.println("返回："+res.split("\n")[1]);
//        RedisPlugin masterRedis = new RedisPlugin("master", "localhost", "redisqht");
//        masterRedis.start();
//        com.jfinal.plugin.redis.Cache bbsCache = Redis.use("master");
////        bbsCache.set();
//        bbsCache.setex("key", 20, "value");
//        bbsCache.getJedis().ttl("key");
//        int i = 10;
//        while (i > 1) {
//
//            try {
//                Thread.currentThread().sleep(1000l);
//                System.out.println("" + bbsCache.getJedis().ttl("key"));
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            System.out.println("====" +i);
//            i--;
//        }
//        System.out.println(bbsCache.get("key").toString());


    }

}
