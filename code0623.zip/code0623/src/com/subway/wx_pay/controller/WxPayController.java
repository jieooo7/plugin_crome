package com.subway.wx_pay.controller;

import com.google.gson.Gson;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.subway.wx_pay.model.response.OpenIdModel;
import com.subway.wx_pay.util.SignUtil;
import com.subway.wx_pay.util.Signature;
import com.subway.wx_pay.util.XMLParser;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.Map;

/**
 * Created by thy on 17-5-3.
 */
public class WxPayController extends Controller {
//支付回调通知
    @ActionKey("wx/notify")
    public void wxNotify() {

        String xmlPara = getPara();

        String success = "<xml>\n" +
                "  <return_code><![CDATA[SUCCESS]]></return_code>\n" +
                "  <return_msg><![CDATA[OK]]></return_msg>\n" +
                "</xml>";

        String fail = "<xml>\n" +
                "  <return_code><![CDATA[FAIL]]></return_code>\n" +
                "  <return_msg><![CDATA[参数格式校验错误]]></return_msg>\n" +
                "</xml>";

        Map<String, Object> map = null;
        try {
            map = XMLParser.getMapFromXML(xmlPara);
            if (map.get("return_code").toString().equals("SUCCESS") && map.get("result_code").toString().equals("SUCCESS")) {
                if (Signature.checkIsSignValidFromResponseString(xmlPara)) {

                    System.out.println("返回============" + map.get("out_trade_no"));
                    //存储逻辑判断，对照金额，标记交易状态
                    if (true) {
                        renderText(success);//验证没问题的话
                    } else {
                        renderText(fail);
                    }

                }
            }
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }
    }
//    设置端口转发
//（1）首先：把该linux服务器占用80号端口的服务关闭；
//    （2）打开服务器的远程转发功能，执行以下命令：
//    sudo nano /etc/ssh/sshd_config
//    在/etc/ssh/sshd_config文件末尾加入一句：
//    GatewayPorts yes
//    然后重启SSH：sudo service sshd restart
//      ssh -R 80:localhost:8080 root@test.qhtpay.cn (这句话的意思是，把发到80转发到本地8080
//    Yb4581844

    @ActionKey("wx/config")
    public void wxConfig() {

//判断请求方式
        if("GET".equalsIgnoreCase(getRequest().getMethod().toUpperCase())){


            String signature = getPara("signature");
            String timestamp = getPara("timestamp");
            String nonce = getPara("nonce");
            String echostr = getPara("echostr");

            if (SignUtil.checkSignature(signature, timestamp, nonce)) {
                renderText(echostr);
            } else {
                renderText("");
            }
        }


        if("POST".equalsIgnoreCase(getRequest().getMethod().toUpperCase())){

        }

    }
//获取用户openid后的重定向页面
    @ActionKey(value = "wx/getCode")
    public void wxGetCode() {
//获取openid
        String code=getPara("code");
        String state=getPara("state");
        String appid="wxe1904df24ebf4cbe";
        String secret="67e5d1e7e8b9c68657026ed814f214d6";

        System.out.println("code:"+code);
        String url="https://api.weixin.qq.com/sns/oauth2/access_token?appid=wxe1904df24ebf4cbe&secret=67e5d1e7e8b9c68657026ed814f214d6&code="+code+"&grant_type=authorization_code";
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();

        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()){
                String body=response.body().string();
//                string()不能多次调用
//                jfinal 3.0默认 json 实现暂不支持 json 到 object 的转换
                System.out.println("返回============" +body);
                Gson gson = new Gson();

                OpenIdModel openIdModel= gson.fromJson(body, OpenIdModel.class);
                System.out.println("openId:" +openIdModel.getOpenid());
                if(openIdModel.getOpenid()!=null){

                    renderText(openIdModel.getOpenid());
                }
                //全部做ajax请求
                //当点击菜单时，根据openid判断是否绑定，没有绑定则获取openid后跳转到绑定页面
                //使用openid直接获取预付单号
        }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



}


