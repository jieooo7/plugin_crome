package com.subway.model.requestModel;

import java.util.List;

/**
 * Created by thy on 17-4-27.
 */
public class TravelerModel {

    private List<Passenger> data_list;


    public List<Passenger> getData_list() {
        return data_list;
    }

    public void setData_list(List<Passenger> data_list) {
        this.data_list = data_list;
    }

    public class Passenger{
        private String name;

        private String identity_infor_id;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIdentity_infor_id() {
            return identity_infor_id;
        }

        public void setIdentity_infor_id(String identity_infor_id) {
            this.identity_infor_id = identity_infor_id;
        }
    }


}
