package com.subway.model.dataModel;

import java.util.Map;

/**
 * Created by thy on 17-5-19.
 */
public class PrepayModel {
    private int member_id;
    private Map<String,String> prepay;

    public PrepayModel() {
    }

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public Map<String, String> getPrepay() {
        return prepay;
    }

    public void setPrepay(Map<String, String> prepay) {
        this.prepay = prepay;
    }
}
