package com.subway.model.dataModel;

/**
 * Created by thy on 17-4-27.
 */
public class ChargeOrderModel {


    private int member_id;
    private int end_at;
    private String order_no;
    private String payment;
    private double fee;
    private String status;

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public int getEnd_at() {
        return end_at;
    }

    public void setEnd_at(int end_at) {
        this.end_at = end_at;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
