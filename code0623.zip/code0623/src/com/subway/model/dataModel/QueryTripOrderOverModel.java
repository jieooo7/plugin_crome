package com.subway.model.dataModel;

/**
 * Created by thy on 17-4-27.
 */
public class QueryTripOrderOverModel {
    private int member_id;
    private int identity_infor_id;
    private String order_no;
    private String real_name;

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public int getIdentity_infor_id() {
        return identity_infor_id;
    }

    public void setIdentity_infor_id(int identity_infor_id) {
        this.identity_infor_id = identity_infor_id;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getReal_name() {
        return real_name;
    }

    public void setReal_name(String real_name) {
        this.real_name = real_name;
    }
}
