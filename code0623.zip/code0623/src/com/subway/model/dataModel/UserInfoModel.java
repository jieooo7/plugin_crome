package com.subway.model.dataModel;

/**
 * Created by thy on 17-4-27.
 */
public class UserInfoModel {

    private int member_id;
    private int member_type;
    private int sex;
    private String real_name;
    private String cellphone;
    private boolean is_real_name;

    public UserInfoModel() {
    }

    public UserInfoModel(int member_id, int member_type, String real_name, String cellphone, boolean is_real_name) {
        this.member_id = member_id;
        this.member_type = member_type;
        this.real_name = real_name;
        this.cellphone = cellphone;
        this.is_real_name = is_real_name;
    }


    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public int getMember_type() {
        return member_type;
    }

    public void setMember_type(int member_type) {
        this.member_type = member_type;
    }

    public String getReal_name() {
        return real_name;
    }

    public void setReal_name(String real_name) {
        this.real_name = real_name;
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }


    public void setIs_real_name(boolean is_real_name) {
        this.is_real_name = is_real_name;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public boolean isIs_real_name() {
        return is_real_name;
    }
}
