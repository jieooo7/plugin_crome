package com.subway.model.dataModel;

/**
 * Created by thy on 17-4-26.
 */
public class PassengerModel {

    private String real_name;
    private String id_card;


    public PassengerModel() {
    }

    public PassengerModel(String real_name, String id_card) {
        this.real_name = real_name;
        this.id_card = id_card;
    }

    public String getReal_name() {
        return real_name;
    }

    public void setReal_name(String real_name) {
        this.real_name = real_name;
    }

    public String getId_card() {
        return id_card;
    }

    public void setId_card(String id_card) {
        this.id_card = id_card;
    }
}
