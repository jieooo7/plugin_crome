package com.subway.model.dataModel;

import java.math.BigDecimal;

/**
 * Created by thy on 17-5-17.
 */
public class BalanceModel {

    private int member_id;
    private BigDecimal balance;

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
}
