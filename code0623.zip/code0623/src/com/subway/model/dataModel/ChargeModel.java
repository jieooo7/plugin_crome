package com.subway.model.dataModel;

/**
 * Created by thy on 17-4-27.
 */
public class ChargeModel {
    private int member_id;
    private String  recharge_order_id;

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public String getRecharge_order_id() {
        return recharge_order_id;
    }

    public void setRecharge_order_id(String recharge_order_id) {
        this.recharge_order_id = recharge_order_id;
    }
}
