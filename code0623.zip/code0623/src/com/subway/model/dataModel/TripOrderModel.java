package com.subway.model.dataModel;

/**
 * Created by thy on 17-4-27.
 */
public class TripOrderModel {
    private int member_id;
    private String  order_no;

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }
}
