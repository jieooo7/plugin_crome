package com.subway.model.dataModel;

/**
 * Created by thy on 17-4-26.
 */
public class MemberIdModel {
    private int member_id;

    public MemberIdModel(int member_id) {
        this.member_id = member_id;
    }

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }
}
