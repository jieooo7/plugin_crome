package com.subway.model.dataModel;

import java.util.List;

/**
 * Created by thy on 17-4-26.
 */
public class ListModel<T> {


    private List<T> data_list;

    public ListModel(List<T> data_list) {
        this.data_list = data_list;
    }

    public List<T> getData_list() {
        return data_list;
    }

    public void setData_list(List<T> data_list) {
        this.data_list = data_list;
    }
}
