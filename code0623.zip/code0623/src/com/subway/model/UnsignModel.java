package com.subway.model;

/**
 * Created by thy on 17-5-10.
 */
public class UnsignModel<T> {

    private String status="0000";

    private String msg="";

    private T data;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
