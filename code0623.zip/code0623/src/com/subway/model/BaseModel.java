package com.subway.model;

import com.subway.config.constant.ErrorCode;

/**
 * Created by thy on 16-11-7.
 */

public class BaseModel<T> {

    private String status="0000";

    private String msg="";
    private String sign="";

    private T data;


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public void setError(String status){
        this.status=status;
        this.msg= ErrorCode.getErrorMsg(status);

    }
}
