package com.subway.config;

import com.jfinal.config.Routes;
import com.subway.controller.*;
import com.subway.interceptor.GlobalInterceptor;

/**
 * Created by thy on 17-4-24.
 */
public class RouteInterceptorConfig extends Routes{
    @Override
    public void config() {
        addInterceptor(new GlobalInterceptor());
        add("/user", UserController.class);
        add("/passger", PassengerController.class);
        add("/user_info", UserInfoController.class);
        add("/charge", ChargeController.class);
        add("/trip", TripController.class);
        add("/feed", FeedbackController.class);
    }
}
