package com.subway.config.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by thy on 17-4-24.
 */
public class ErrorCode {
    //数据库内部错误，返回http_response_code=500

    public static final String NO_SIGN = "1001";
    public static final String SIGN_ERROR = "1002";
    public static final String NO_TEL = "1003";
    public static final String INVALID_TEL = "1004";
    public static final String NO_PASS = "1005";
    public static final String INVALID_PASS = "1006";
    public static final String NO_VERCODE = "1007";
    public static final String INVALID_VERCODE = "1008";
    public static final String NO_MEMBER_ID = "1009";
    public static final String INVALID_MEMBER_ID = "1010";
    public static final String NO_NAME = "1011";
    public static final String INVALID_NAME = "1012";
    public static final String NO_ORDER_NO = "1013";
    public static final String INVALID_ORDER_NO = "1014";
    public static final String NO_PAYMENT = "1015";
    public static final String INVALID_PAYMENT = "1016";
    public static final String NO_PASSENGERS = "1017";
    public static final String INVALID_PASSENGERS = "1018";
    public static final String NO_ID_CARD = "1019";
    public static final String INVALID_ID_CARD = "1020";
    public static final String NO_FEE = "1021";
    public static final String INVALID_FEE = "1022";
    public static final String NO_START_STATION_ID = "1023";
    public static final String INVALID_START_STATION_ID = "1024";
    public static final String USED = "1025";
    public static final String REPEAT = "1026";
    public static final String ERROR_PASS = "1027";
    public static final String NO_DATA = "1028";
    public static final String NO_PASS_OR_CODE = "1029";
    public static final String NO_PASS_ADD = "1030";
    public static final String NO_REQ = "1031";
    public static final String HAVE_TEL = "1032";
    public static final String REAL_NAME_FAIL = "1033";
    public static final String NO_SMS = "1034";
    public static final String TOO_MORE_SMS = "1035";
    public static final String SYSTEM_ERROR = "1036";
    public static final String NO_QUESTION = "1037";
    public static final String NOT_ENOUGH_MONEY = "1038";


    protected static final Map<String, String> ERROR_MAP = new HashMap<String, String>();

    static {
        ERROR_MAP.put(NO_SIGN,"未签名");
        ERROR_MAP.put(SIGN_ERROR,"签名错误");
        ERROR_MAP.put(NO_TEL,"请填写手机号");
        ERROR_MAP.put(INVALID_TEL,"手机号码不正确");
        ERROR_MAP.put(NO_PASS,"请输入密码");
        ERROR_MAP.put(INVALID_PASS,"密码格式不正确");
        ERROR_MAP.put(NO_VERCODE,"请输入验证码");
        ERROR_MAP.put(INVALID_VERCODE,"验证码错误");
        ERROR_MAP.put(NO_MEMBER_ID,"请输入用户id");
        ERROR_MAP.put(INVALID_MEMBER_ID,"用户id不正确或不存在");
        ERROR_MAP.put(NO_NAME,"请输入姓名");
        ERROR_MAP.put(INVALID_NAME,"姓名格式错误");
        ERROR_MAP.put(NO_ORDER_NO,"请输入订单号");
        ERROR_MAP.put(INVALID_ORDER_NO,"订单号错误或不存在");
        ERROR_MAP.put(NO_PAYMENT,"请选择支付方式");
        ERROR_MAP.put(INVALID_PAYMENT,"支付不可用");
        ERROR_MAP.put(NO_PASSENGERS,"请输入乘客列表");
        ERROR_MAP.put(INVALID_PASSENGERS,"乘客列表格式错误");
        ERROR_MAP.put(NO_ID_CARD,"请输入身份证号码");
        ERROR_MAP.put(INVALID_ID_CARD,"身份证号码格式错误");
        ERROR_MAP.put(NO_FEE,"请输入总费用");
        ERROR_MAP.put(INVALID_FEE,"金额格式错误");
        ERROR_MAP.put(NO_START_STATION_ID,"请输入起始站");
        ERROR_MAP.put(INVALID_START_STATION_ID,"起始站不可用");
        ERROR_MAP.put(USED,"已被使用");
        ERROR_MAP.put(REPEAT,"重复");
        ERROR_MAP.put(ERROR_PASS,"用户名或密码错误");
        ERROR_MAP.put(NO_DATA,"数据不存在");
        ERROR_MAP.put(NO_PASS_OR_CODE,"请输入密码或者验证码");
        ERROR_MAP.put(NO_PASS_ADD,"请输入新密码");
        ERROR_MAP.put(NO_REQ,"没有请求参数");
        ERROR_MAP.put(HAVE_TEL,"手机号已经注册");
        ERROR_MAP.put(REAL_NAME_FAIL,"实名认证失败");
        ERROR_MAP.put(NO_SMS,"发送失败");
        ERROR_MAP.put(TOO_MORE_SMS,"短信发送太频繁");
        ERROR_MAP.put(SYSTEM_ERROR,"系统错误，请稍后重试");
        ERROR_MAP.put(NO_QUESTION,"问题不能为空");
        ERROR_MAP.put(NOT_ENOUGH_MONEY,"余额不足");
    }

    public static String getErrorMsg(String code) {
        return ERROR_MAP.get(code);
    }

    public static void main(String[] args) {

        System.out.println(getErrorMsg("1009"));
        return;
//        try {
//            Class clazz = Class.forName("com.subway.config.constant.ErrorCode");
//            Field[] fields = clazz.getDeclaredFields();
//            Object obj = clazz.newInstance();
//
//
////            int code=1000;
////            for(Field field : fields){
////                int modifiers = field.getModifiers();
////                if (Modifier.isPrivate(modifiers)) {
//////                    field.get(obj)  取值
////                    code++;
////                    field.set(obj,""+code);
////                    System.out.println(" private static final String " + field.getName() + " = \""+field.get(obj)+"\";");
////                }
////            }
//
//            for (Field field : fields) {
//
//                field.setAccessible(true);
////                field.set
//                int modifiers = field.getModifiers();
//                if (Modifier.isPublic(modifiers)) {
////                    field.get(obj)  取值
//
//                    System.out.println("ERROR_MAP.put(" + field.getName()+ ",\""+ERROR_MAP.get(""+field.get(obj))+"\");");
//                }
//
//            }
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        } catch (InstantiationException e) {
//            e.printStackTrace();
//        }

    }
}
