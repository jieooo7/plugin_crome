package com.subway.config.constant;

/**
 * Created by thy on 17-4-24.
 */
public class ParaName {
    public  static String REQ_PARA="reqdata";
}
