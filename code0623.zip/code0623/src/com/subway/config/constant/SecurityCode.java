package com.subway.config.constant;

/**
 * Created by thy on 17-4-24.
 */
public class SecurityCode {
    public static String AES_Key="1234567887654321";
}
