package com.subway.config.constant;

/**
 * Created by thy on 17-4-24.
 */
public class HttpStatusCode {
    public static int REDIRECT=302;
}
