package com.subway.config;

import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.wall.WallFilter;
import com.jfinal.config.*;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.druid.DruidPlugin;
import com.jfinal.plugin.druid.IDruidStatViewAuth;
import com.jfinal.plugin.ehcache.EhCachePlugin;
import com.jfinal.plugin.redis.RedisPlugin;
import com.jfinal.template.Engine;
import com.subway.common.model._MappingKit;
import com.subway.handler.DruidStatViewHandler;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by thy on 17-4-20.
 */

public class Config extends JFinalConfig {

    //    此方法用来配置 JFinal 常量值
    public void configConstant(Constants me) {
// 第一次使用use加载的配置将成为主配置,可以通过PropKit.get(...)直接取值
        PropKit.use("config.txt");
//        me.setRenderFactory();

        me.setDevMode(true);

    }


//    此方法用来配置 JFinal 访问路由
    public void configRoute(Routes me) {
//        用于为该 Routes 内部的所有 Controller 设置视
//        图渲染时的基础路径,该基础路径与 Rutes.add(..., viewType)方法传入的 viewPath 以及
//        Controller.render(view) 方法传入的 view 参数联合组成最终的视图路径,规则如下:
//        finalView = baseViewPath + viewPath + view
//        注意:当 view 以 “/” 字符打头时表示绝对路径,baseViewPath 与 viewPath 将被忽略。
//        me.setBaseViewPath("/");
//        me.addInterceptor(new FrontInterceptor());
//        me.add("/", UserController.class);/login 直接访问
        me.add(new WxRoutes());
        me.add(new RouteInterceptorConfig());
    }


//    方法用来配置 Template Engine
    public void configEngine(Engine me) {
    }

//
//    用来配置 JFinal 的全局拦截器,全局拦截器将拦截所有 action 请求,除非使用
//    @Clear 在 Controller 中清除
    public void configInterceptor(Interceptors me) {
    }

//    来配置 J来配置 JFinal 的 Handler,
//    如下代码配置了名为 ResourceHandler 的处理器, Handler
//    可以接管所有 web 请求,并对应用拥有完全的控制权,可以很方便地实现更高层的功能性扩
//            展
    public void configHandler(Handlers me) {
//        me.add(new ResourceHandler());
	    DruidStatViewHandler dvh =  new DruidStatViewHandler("/druid",
			    new IDruidStatViewAuth(){
				    public boolean isPermitted(HttpServletRequest request) {
					    String contextPath = request.getContextPath();
					    // String servletPath = request.getServletPath();
					    String requestURI = request.getRequestURI();


					    if (contextPath == null) { // root context
						    contextPath = "";
					    }
					    // String uri = contextPath + servletPath;
					    // String path = requestURI.substring(contextPath.length() + servletPath.length());
					    int index = contextPath.length() + "/druid".length();
					    String path = requestURI.substring(index);
					    if("/login.html".equals(path) ||"/submitLogin".equals(path)//
							    || path.startsWith("/css")//
							    || path.startsWith("/js") //
							    || path.startsWith("/img")){
					    	return true;
					    }
					    String name=(String) request.getSession().getAttribute("druid-user");
					    if("thy".equals(name)){
						    return true;

					    }
					    return false;
				    }
			    });


        me.add(dvh);
//	    http://localhost:8089/druid/index.html

    }

//    PropKit 工具类用来操作外部配置文件。PropKit 可以极度方便地在系统任意时空使用


    public void configPlugin(Plugins me) {
        DruidPlugin cp=createDruidPlugin();
        cp.addFilter(new StatFilter());
        WallFilter wall = new WallFilter();
        wall.setDbType("mysql");
        cp.addFilter(wall);
        me.add(cp);
        ActiveRecordPlugin arp = new ActiveRecordPlugin(cp);
        _MappingKit.mapping(arp);
        me.add(arp);
//        arp.addMapping("qht_member","member_id", UserInfo.class);

        RedisPlugin masterRedis = new RedisPlugin("master", PropKit.get("redis_host"),PropKit.get("redis_pass"));
        me.add(masterRedis);
	
	    me.add(new EhCachePlugin());
//	    put(String cacheName, Object key, Object value)
    }


    public static DruidPlugin createDruidPlugin() {
        return new DruidPlugin(PropKit.get("jdbcUrl"), PropKit.get("user"), PropKit.get("password").trim());
    }
}