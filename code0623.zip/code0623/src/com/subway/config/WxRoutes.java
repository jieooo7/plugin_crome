package com.subway.config;

import com.jfinal.config.Routes;
import com.subway.wx_pay.controller.WxPayController;

/**
 * Created by thy on 17-5-9.
 */
public class WxRoutes extends Routes {
    @Override
    public void config() {
        add("/wxpay", WxPayController.class);
    }
}
