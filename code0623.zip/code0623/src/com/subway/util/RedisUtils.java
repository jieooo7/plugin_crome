package com.subway.util;

import com.jfinal.plugin.redis.Cache;
import com.jfinal.plugin.redis.Redis;

import java.util.Set;

/**
 * Created by thy on 17-5-26.
 */
public class RedisUtils {

	private RedisUtils() {
		config();
	}

	private static class InstanceHolder{
		private static final RedisUtils instance = new RedisUtils();
	}

	public static RedisUtils getInstance() {
		return InstanceHolder.instance;
	}

	/**
	 * redis的配置
	 */
	private void config(){

	}

	private void remove(final String... keys) {
		for (String key : keys) {
			remove(key);
		}
	}

	/**
	 * 批量删除key
	 *
	 * @param pattern
	 */
	private void removePattern(final String pattern) {
		Set<String> keys = getCache().keys(pattern);
		if (keys.size() > 0)
			getCache().del(keys);
	}

	/**
	 * 删除对应的value
	 *
	 * @param key
	 */


	private void remove(final String key) {
		if (exists(key)) {
			getCache().del(key);
		}
	}

	/**
	 * 判断缓存中是否有对应的value
	 *
	 * @param key
	 * @return
	 */
	private boolean exists(final String key) {
		return getCache().exists(key);
	}

	/**
	 * 读取缓存
	 *
	 * @param key
	 * @return
	 */
	private Object get(final String key) {
		Object result = null;
		result = getCache().get(key);
		return result;
	}

	/**
	 * 写入缓存
	 *
	 * @param key
	 * @param value
	 * @return
	 */
	private boolean set(final String key, Object value) {
		boolean result = false;
		try {
			getCache().set(key, value);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 写入缓存
	 *
	 * @param key
	 * @param value
	 * @return
	 */
	private boolean set(final String key, Object value, int expireTime) {
		boolean result = false;
		try {
			getCache().setex(key,expireTime,value);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}


	private Cache getCache(){

		return Redis.use("master");
	}


}
