package com.subway.util;

import com.google.gson.Gson;
import okhttp3.*;
import java.io.IOException;

/**
 * Created by thy on 17-5-26.
 */
public class HttpUtils {

	private OkHttpClient mOkHttpClient;
	private Gson mGson;

	private HttpUtils() {
		mOkHttpClient = new OkHttpClient();
		mGson = new Gson();
	}

	private static class InstanceHolder{
		private static final HttpUtils instance = new HttpUtils();
	}

	public static HttpUtils getInstance() {
		return HttpUtils.InstanceHolder.instance;
	}



	/**
	 * 同步的Get请求
	 *
	 * @param url
	 * @return Response
	 */
	private Response _getAsyn(String url) throws IOException
	{
		final Request request = new Request.Builder()
				.url(url)
				.build();
		Call call = mOkHttpClient.newCall(request);
		Response execute = call.execute();
		return execute;
	}


	/**
	 * 同步的Post请求
	 *
	 * @param url
	 * @param params post的参数
	 * @return
	 */
	private Response post(String url, Param... params) throws IOException
	{
		Request request = buildPostRequest(url, params);
		Response response = mOkHttpClient.newCall(request).execute();
		return response;
	}



	private Request buildPostRequest(String url, Param[] params)
	{
		if (params == null)
		{
			params = new Param[0];
		}
		FormBody.Builder builder = new FormBody.Builder();
		for (Param param : params)
		{
			builder.add(param.key, param.value);
		}
		RequestBody requestBody = builder.build();
		return new Request.Builder()
				.url(url)
				.post(requestBody)
				.build();
	}


	public static class Param
	{
		public Param()
		{
		}

		public Param(String key, String value)
		{
			this.key = key;
			this.value = value;
		}

		String key;
		String value;
	}


}
