package com.subway.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * Created by thy on 17-4-28.
 */
public class OrderNoGenerate {


    public static String generate(String payType){

        String random=randomGenerate();
        SimpleDateFormat dateformat=new SimpleDateFormat("yyyyMMddHHmmss");
        String date=dateformat.format(new Date());

        return  payType+date+random;


    }

    public static String randomGenerate(){


            Random random = new Random();

            int code = random.nextInt(10000) % 10000 + (random.nextInt(9) + 1) * 10000;

            return ""+code;

    }

    public static String smscodeGenerate(){


            Random random = new Random();

            int code = random.nextInt(100000) % 100000 + (random.nextInt(9) + 1) * 100000;

            return ""+code;

    }

}
