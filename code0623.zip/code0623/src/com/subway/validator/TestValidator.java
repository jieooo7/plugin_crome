package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-4-27.
 */
public class TestValidator extends BaseValidator{
    @Override
    protected void validate(Controller c) {
        validateRequiredValue(c.getAttr("member_id"),"9999","测试");
    }

    @Override
    protected void handleError(Controller c) {
        BaseModel model = new BaseModel();
        model.setStatus("9999");
        model.setMsg(c.getAttr("9999"));

        getInvocation().setReturnValue(model);

    }
}
