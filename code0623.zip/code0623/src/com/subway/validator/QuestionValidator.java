package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-5-16.
 */
public class QuestionValidator extends BaseValidator{
    @Override
    protected void validate(Controller c) {
        validateRequiredValue(c.getAttr("question"), ErrorCode.NO_QUESTION,ErrorCode.getErrorMsg(ErrorCode.NO_QUESTION));
    }

    @Override
    protected void handleError(Controller c) {
        BaseModel model = new BaseModel();
        model.setStatus(ErrorCode.NO_QUESTION);
        model.setMsg(c.getAttr(ErrorCode.NO_QUESTION));

        getInvocation().setReturnValue(model);


    }
}