package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-5-2.
 */
public class TelValidator extends BaseValidator{
    @Override
    protected void validate(Controller c) {

        String regExp = "^((13[0-9])|(15[^4])|(18[0,2,3,5-9])|(17[0-8])|(147))\\d{8}$";
        customValidateRegex(c.getAttr("cellphone"),regExp, ErrorCode.INVALID_TEL,ErrorCode.getErrorMsg(ErrorCode.INVALID_TEL));

    }

    @Override
    protected void handleError(Controller c) {

        BaseModel model = new BaseModel();
        model.setStatus(ErrorCode.INVALID_TEL);
        model.setMsg(c.getAttr(ErrorCode.INVALID_TEL));

        getInvocation().setReturnValue(model);

    }
}
