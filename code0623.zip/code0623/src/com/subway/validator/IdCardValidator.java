package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-5-2.
 */
public class IdCardValidator extends BaseValidator{
    @Override
    protected void validate(Controller c) {
        String regExp = "[1-9]\\d{13,16}[a-zA-Z0-9]{1}";
        customValidateRegex(c.getAttr("id_card"),regExp, ErrorCode.INVALID_ID_CARD,ErrorCode.getErrorMsg(ErrorCode.INVALID_ID_CARD));
    }

    @Override
    protected void handleError(Controller c) {
        BaseModel model = new BaseModel();
        model.setStatus(ErrorCode.INVALID_ID_CARD);
        model.setMsg(c.getAttr(ErrorCode.INVALID_ID_CARD));

        getInvocation().setReturnValue(model);


    }
}