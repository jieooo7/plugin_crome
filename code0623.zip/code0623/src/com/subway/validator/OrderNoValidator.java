package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-5-2.
 */
public class OrderNoValidator extends BaseValidator{
    @Override
    protected void validate(Controller c) {
        validateRequiredValue(c.getAttr("order_no"), ErrorCode.NO_ORDER_NO,ErrorCode.getErrorMsg(ErrorCode.NO_ORDER_NO));
    }

    @Override
    protected void handleError(Controller c) {
        BaseModel model = new BaseModel();
        model.setStatus(ErrorCode.NO_ORDER_NO);
        model.setMsg(c.getAttr(ErrorCode.NO_ORDER_NO));

        getInvocation().setReturnValue(model);


    }
}