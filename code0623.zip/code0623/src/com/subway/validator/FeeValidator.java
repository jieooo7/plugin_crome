package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-5-2.
 */
public class FeeValidator  extends BaseValidator{
    @Override
    protected void validate(Controller c) {

        validateDoubleValue(c.getAttr("fee"),0.00, 100000000.00,ErrorCode.INVALID_TEL,ErrorCode.getErrorMsg(ErrorCode.INVALID_TEL));

    }

    @Override
    protected void handleError(Controller c) {

        BaseModel model = new BaseModel();
        model.setStatus(ErrorCode.INVALID_TEL);
        model.setMsg(c.getAttr(ErrorCode.INVALID_TEL));

        getInvocation().setReturnValue(model);

    }
}