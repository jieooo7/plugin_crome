package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-5-2.
 */
public class CodeValidator extends BaseValidator{
    @Override
    protected void validate(Controller c) {
        validateRequiredValues(c.getAttr("password"),c.getAttr("ver_code"), ErrorCode.NO_PASS_OR_CODE,ErrorCode.getErrorMsg(ErrorCode.NO_PASS_OR_CODE));
    }

    @Override
    protected void handleError(Controller c) {

        BaseModel model = new BaseModel();
        model.setStatus(ErrorCode.NO_PASS_OR_CODE);
        model.setMsg(ErrorCode.NO_PASS_OR_CODE);

        getInvocation().setReturnValue(model);

    }
}
