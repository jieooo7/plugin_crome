package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-5-2.
 */
public class NameValidator extends BaseValidator{
    @Override
    protected void validate(Controller c) {
        String regExp = "[\u4E00-\u9FA5]{2,7}";
        customValidateRegex(c.getAttr("real_name"),regExp, ErrorCode.INVALID_NAME,ErrorCode.getErrorMsg(ErrorCode.INVALID_NAME));
    }

    @Override
    protected void handleError(Controller c) {
        BaseModel model = new BaseModel();
        model.setStatus(ErrorCode.INVALID_NAME);
        model.setMsg(c.getAttr(ErrorCode.INVALID_NAME));

        getInvocation().setReturnValue(model);


    }
}