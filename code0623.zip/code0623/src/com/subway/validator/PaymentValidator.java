package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-5-2.
 */
public class PaymentValidator  extends BaseValidator{
    @Override
    protected void validate(Controller c) {
        validateRequiredValue(c.getAttr("payment"), ErrorCode.NO_PAYMENT,ErrorCode.getErrorMsg(ErrorCode.NO_PAYMENT));
    }

    @Override
    protected void handleError(Controller c) {
        BaseModel model = new BaseModel();
        model.setStatus(ErrorCode.NO_PAYMENT);
        model.setMsg(c.getAttr(ErrorCode.NO_PAYMENT));

        getInvocation().setReturnValue(model);


    }
}
