package com.subway.validator;

import com.jfinal.aop.Invocation;
import com.jfinal.kit.StrKit;
import com.jfinal.validate.Validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by thy on 17-4-25.
 */
public abstract class BaseValidator extends Validator {


    public BaseValidator() {
//        setShortCircuit(true);
    }

    protected void validateRequiredValue(String value, String errorKey, String errorMessage) {
        if (StrKit.isBlank(value)) {
            addError(errorKey, errorMessage);
        }
    }


    protected void validateRequiredValues(String value1,String value2, String errorKey, String errorMessage) {
        if (StrKit.isBlank(value1)&&StrKit.isBlank(value2)) {
            addError(errorKey, errorMessage);
        }
    }

    protected void customValidateRegex(String value, String regExpression, boolean isCaseSensitive, String errorKey, String errorMessage) {
        if (value == null) {
            addError(errorKey, errorMessage);
            return ;
        }
        Pattern pattern = isCaseSensitive ? Pattern.compile(regExpression) : Pattern.compile(regExpression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(value);
        if (!matcher.matches()) {
            addError(errorKey, errorMessage);
        }
    }


    protected void validateDoubleValue(String value, double min, double max, String errorKey, String errorMessage) {
        if (StrKit.isBlank(value)) {
            addError(errorKey, errorMessage);
            return ;
        }
        try {
            double temp = Double.parseDouble(value.trim());
            if (temp < min || temp > max) {
                addError(errorKey, errorMessage);
            }
        }
        catch (Exception e) {
            addError(errorKey, errorMessage);
        }
    }



    protected void customValidateRegex(String value, String regExpression, String errorKey, String errorMessage) {
        customValidateRegex(value, regExpression, true, errorKey, errorMessage);
    }

    public Invocation getInvocation(){
        return super.invocation;
    }

}
