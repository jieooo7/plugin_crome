package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-5-2.
 */
public class PassWordValidator extends BaseValidator{
    @Override
    protected void validate(Controller c) {
        validateRequiredValue(c.getAttr("new_password"), ErrorCode.NO_PASS_ADD,ErrorCode.getErrorMsg(ErrorCode.NO_PASS_ADD));
    }

    @Override
    protected void handleError(Controller c) {
        BaseModel model = new BaseModel();
        model.setStatus(ErrorCode.NO_PASS_ADD);
        model.setMsg(c.getAttr(ErrorCode.NO_PASS_ADD));

        getInvocation().setReturnValue(model);


    }
}
