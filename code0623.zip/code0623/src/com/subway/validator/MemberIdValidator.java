package com.subway.validator;

import com.jfinal.core.Controller;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;

/**
 * Created by thy on 17-5-2.
 */
public class MemberIdValidator extends BaseValidator{
    @Override
    protected void validate(Controller c) {
        validateRequiredValue(c.getAttr("member_id"), ErrorCode.INVALID_FEE,ErrorCode.getErrorMsg(ErrorCode.INVALID_FEE));
    }

    @Override
    protected void handleError(Controller c) {
        BaseModel model = new BaseModel();
        model.setStatus(ErrorCode.INVALID_FEE);
        model.setMsg(c.getAttr(ErrorCode.INVALID_FEE));

        getInvocation().setReturnValue(model);


    }
}
