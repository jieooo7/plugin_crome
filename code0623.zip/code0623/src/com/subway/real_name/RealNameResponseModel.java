package com.subway.real_name;

/**
 * Created by thy on 17-5-10.
 */
public class RealNameResponseModel {

    private String code;
    private String message;
    private String out_trade_no;
    private String sign;
    private String sys_time;
    private String sys_tran_id;
    private String tran_amt;
    private String tran_time;


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getOut_trade_no() {
        return out_trade_no;
    }

    public void setOut_trade_no(String out_trade_no) {
        this.out_trade_no = out_trade_no;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getSys_time() {
        return sys_time;
    }

    public void setSys_time(String sys_time) {
        this.sys_time = sys_time;
    }

    public String getSys_tran_id() {
        return sys_tran_id;
    }

    public void setSys_tran_id(String sys_tran_id) {
        this.sys_tran_id = sys_tran_id;
    }

    public String getTran_amt() {
        return tran_amt;
    }

    public void setTran_amt(String tran_amt) {
        this.tran_amt = tran_amt;
    }

    public String getTran_time() {
        return tran_time;
    }

    public void setTran_time(String tran_time) {
        this.tran_time = tran_time;
    }
}
