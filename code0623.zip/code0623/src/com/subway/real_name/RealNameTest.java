package com.subway.real_name;


import com.google.gson.Gson;
import okhttp3.*;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RealNameTest {
  private static String baseUrl = "http://120.76.209.88:8080/molink-gw/v1.0/realname/";

  public static void main(String[] args) throws Exception {
	  String realName="庄贺冰";
	  String idNo="350627199110183017";
    SimpleDateFormat dateformat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	  
    String out_trade_no = "201611250000000002106";
    String tran_time = dateformat.format(new Date());;
    String verify_type = "0220";
    String company_code = "20170329000018";
    String url = baseUrl + company_code;
    String des_key = "1234@@abcd1234@@abcd$$$$";
    String rsa_key = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBANsrwhP5S/ARqvcq80ataQY+clY1cEttg6ZFx+D49vjqN7AgeewQ23Q7wWnE033RPT0GSQ/OOCTwVbU85yDTEmo8+P1uTons3ENSFZWq6viqZUul+YvsNHXLTL3G5ATczJUM8rcNRUMErQN+6vGCGw78WiqH4vld63Zi6jXXwXLxAgMBAAECgYBxzrwdwRMkmxgK9tuStNNXca/PgjpIgJqfCZcsBDvCr2SxaXvGEE7UgX8CnDkyGSfSe2QO+AeBbucikHh4PAJP/80i58p6oSsgu/H1COD4y4+4ppRtQq6ATMA7IYyOL+dTaneENdz8vpPmWwRtFJMXJs1Lb9VkcQEgskgSkP8QkQJBAPyWim0cEHgnVqtF/KxzKzajpze8k//PuNe8dlbGreE3TaIsY1WFedh5kB3iNdyOLeRRpbkAuLGlhux2nrt6kxUCQQDeIajhujkn34pYqVSfbZEaLIlDsKTZ3gRO91TWV0fMfPLZoKgQt4dtxxqXSdUaXeNQWAASXMU3o6VmbDY4LkdtAkBmam/UT9XJskGtDqKmFciGzhKGQftMdSBAsVTWWJa2Q+NBh3f7fDRsdtXdmBQ4ypmHAygL/GPm+/PaOzqfT9MFAkAtUdq96xucKfx06F9Og7E2EN4UhGat2KEyZz3U2UvZyahWhHOlrXwhBp1DPpoO3hbxnnKtTGYkWuv1AKDzR2XlAkAnGlHJSOavTkLzdauSO/f01KCj4GLO14the628R4FZGjMOXrDYTnS7EShjfGb90Qg8q2tV+igdGIlYGIFFuF63";
    RealNameRequestModel molinkRequest = new RealNameRequestModel();
    molinkRequest.setOut_trade_no(out_trade_no);
    molinkRequest.setTran_time(tran_time);
    molinkRequest.setVerify_type(verify_type);
    molinkRequest.setCompany_code(company_code);
    molinkRequest.setRealName(realName);
    molinkRequest.setIdNo(idNo);
    
    StringBuilder builder = new StringBuilder();
    builder.append(Constants.out_trade_no.toUpperCase() + "=" + out_trade_no);
    builder.append("&" + Constants.tran_time.toUpperCase() + "=" + tran_time);
    
    builder.append("&" + Constants.verify_type.toUpperCase() + "=" + verify_type);
    builder.append("&" + Constants.realName.toUpperCase() + "=" + realName);
    builder.append("&" + Constants.idNo.toUpperCase() + "=" + idNo);

    String sign = RSASignature.sign(new String(builder),rsa_key, "UTF-8");
    molinkRequest.setSign(sign);

    String json = new Gson().toJson(molinkRequest);
    byte[] keybyte = des_key.getBytes();
    byte[] requsest = ThreeDesUtil.encryptMode(keybyte, json.getBytes());
//    RequestBody的数据格式都要指定Content-Type，常见的有三种：
//
//    application/x-www-form-urlencoded 数据是个普通表单
//    multipart/form-data 数据里有文件
//    application/json 数据是个json

    MediaType XML = MediaType.parse("application/html; charset=utf-8");
    OkHttpClient client = new OkHttpClient();
    RequestBody body = RequestBody.create(XML, ThreeDesUtil.byte2Hex(requsest));

    Request request = new Request.Builder()
            .url(url)
            .post(body)
            .build();
    Response response = client.newCall(request).execute();


    System.out.println(response.body().string());
  }

}
