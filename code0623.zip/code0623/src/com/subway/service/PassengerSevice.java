package com.subway.service;

import com.google.gson.Gson;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.subway.model.dataModel.PassengerModel;
import com.subway.real_name.*;
import okhttp3.*;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by thy on 17-4-26.
 */
public class PassengerSevice {
    private static final transient Logger log = LogManager.getLogger(PassengerSevice.class);

    public static PassengerSevice me=new PassengerSevice();

    public int addPassenger(String member_id,String cellphone,String real_name,String id_card){

        boolean isAdd=true;
        Record passenger= Db.findFirst("select * from qht_identity_infor where id_card=?",id_card);
        if(passenger==null){
            passenger=new Record().set("cellphone", cellphone).set("real_name", real_name).
                    set("id_card", id_card).set("create_at",new java.util.Date().getTime()/1000);
            isAdd=Db.save("qht_identity_infor","identity_infor_id", passenger);
        }
        Record realPassenger=null;
        if(isAdd){
            realPassenger=Db.findFirst("select * from qht_passenger where identity_infor_id=?",passenger.getLong("identity_infor_id"));
        }

        if(realPassenger==null){

            if(checkRealName(real_name,id_card)){


                realPassenger=new Record().set("identity_infor_id", passenger.getLong("identity_infor_id")).
                        set("member_id", member_id).set("create_at",new java.util.Date().getTime()/1000);

                Db.save("qht_passenger", realPassenger);
                return Integer.parseInt(String.valueOf(member_id));
            }else {
                return -1;
            }


        }

        return Integer.parseInt(String.valueOf(member_id));

    }


    public List<PassengerModel> passengers(String member_id){


        List<Record> passengers = Db.find("select a.real_name,a.id_card from qht_identity_infor a inner join qht_passenger b on a.identity_infor_id=b.identity_infor_id where b.member_id=? ",member_id);

        List<PassengerModel> list=new ArrayList<PassengerModel>();
        if(list==null){
            return null;
        }

        for(Record record:passengers){
            PassengerModel passenger=new PassengerModel();
            passenger.setReal_name(record.getStr("real_name"));
            passenger.setId_card(record.getStr("id_card"));
            list.add(passenger);
        }

        return list;

    }

    public int realName(String member_id,String cellphone,String real_name,String id_card){
//此处应该传memberid，添加标示位,可以和addpassenger 合并，请求第三方验证,错误提示信息可以添加basemodel参数
        Record passenger= Db.findFirst("select * from qht_identity_infor where id_card=?",id_card);
        if(passenger==null){
           passenger=new Record().set("cellphone", cellphone).set("real_name", real_name).
                   set("id_card", id_card).set("create_at",new java.util.Date().getTime()/1000);
           Db.save("qht_identity_infor","identity_infor_id", passenger);
        }

        if(checkRealName(real_name,id_card)){


            Record realPassenger=new Record().set("identity_infor_id", passenger.getLong("identity_infor_id")).
                    set("member_id", member_id).set("create_at",new java.util.Date().getTime()/1000);

            Db.save("qht_passenger", realPassenger);
            log.info(real_name+"身份证号："+id_card+"实名认证成功");
            return 0;
        }


        return -1;
    }


    public boolean checkRealName(String realName,String idNo){
        String baseUrl = "http://120.76.209.88:8080/molink-gw/v1.0/realname/";
        SimpleDateFormat dateformat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String out_trade_no = "201611250000000002106";
        String tran_time = dateformat.format(new Date());;
        String verify_type = "0220";
        String company_code = "20170329000018";
        String url = baseUrl + company_code;
        String des_key = "1234@@abcd1234@@abcd$$$$";
        String rsa_key = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBANsrwhP5S/ARqvcq80ataQY+clY1cEttg6ZFx+D49vjqN7AgeewQ23Q7wWnE033RPT0GSQ/OOCTwVbU85yDTEmo8+P1uTons3ENSFZWq6viqZUul+YvsNHXLTL3G5ATczJUM8rcNRUMErQN+6vGCGw78WiqH4vld63Zi6jXXwXLxAgMBAAECgYBxzrwdwRMkmxgK9tuStNNXca/PgjpIgJqfCZcsBDvCr2SxaXvGEE7UgX8CnDkyGSfSe2QO+AeBbucikHh4PAJP/80i58p6oSsgu/H1COD4y4+4ppRtQq6ATMA7IYyOL+dTaneENdz8vpPmWwRtFJMXJs1Lb9VkcQEgskgSkP8QkQJBAPyWim0cEHgnVqtF/KxzKzajpze8k//PuNe8dlbGreE3TaIsY1WFedh5kB3iNdyOLeRRpbkAuLGlhux2nrt6kxUCQQDeIajhujkn34pYqVSfbZEaLIlDsKTZ3gRO91TWV0fMfPLZoKgQt4dtxxqXSdUaXeNQWAASXMU3o6VmbDY4LkdtAkBmam/UT9XJskGtDqKmFciGzhKGQftMdSBAsVTWWJa2Q+NBh3f7fDRsdtXdmBQ4ypmHAygL/GPm+/PaOzqfT9MFAkAtUdq96xucKfx06F9Og7E2EN4UhGat2KEyZz3U2UvZyahWhHOlrXwhBp1DPpoO3hbxnnKtTGYkWuv1AKDzR2XlAkAnGlHJSOavTkLzdauSO/f01KCj4GLO14the628R4FZGjMOXrDYTnS7EShjfGb90Qg8q2tV+igdGIlYGIFFuF63";
        RealNameRequestModel molinkRequest = new RealNameRequestModel();
        molinkRequest.setOut_trade_no(out_trade_no);
        molinkRequest.setTran_time(tran_time);
        molinkRequest.setVerify_type(verify_type);
        molinkRequest.setCompany_code(company_code);
        molinkRequest.setRealName(realName);
        molinkRequest.setIdNo(idNo);

        StringBuilder builder = new StringBuilder();
        builder.append(Constants.out_trade_no.toUpperCase() + "=" + out_trade_no);
        builder.append("&" + Constants.tran_time.toUpperCase() + "=" + tran_time);

        builder.append("&" + Constants.verify_type.toUpperCase() + "=" + verify_type);
        builder.append("&" + Constants.realName.toUpperCase() + "=" + realName);
        builder.append("&" + Constants.idNo.toUpperCase() + "=" + idNo);

        String sign = RSASignature.sign(new String(builder),rsa_key, "UTF-8");
        molinkRequest.setSign(sign);

        String json = new Gson().toJson(molinkRequest);
        byte[] keybyte = des_key.getBytes();
        byte[] requsest = ThreeDesUtil.encryptMode(keybyte, json.getBytes());

        MediaType XML = MediaType.parse("application/html; charset=utf-8");
        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(XML, ThreeDesUtil.byte2Hex(requsest));

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
        } catch (IOException e) {
            e.printStackTrace();
        }


        try {

            if(response.isSuccessful()){
                String result=response.body().string();
                RealNameResponseModel model=new Gson().fromJson(result,RealNameResponseModel.class);
                if(model!=null&&model.getCode().equals("0000")){
//                    CODE=0000&MESSAGE=Success&OUT_TRADE_NO=201611010000000062&TRAN_TIME=2016-11-01 11:00:00
//                    验证签名
                    return true;
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


        return false;


    }





}
