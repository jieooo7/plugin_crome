package com.subway.service;

import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;
import com.subway.model.dataModel.MemberIdModel;

/**
 * Created by thy on 17-5-16.
 */
public class FeedbackService {
    public static FeedbackService me=new FeedbackService();

    public void addFeedback(String member_id, String question, BaseModel<MemberIdModel> model){


        Record feedback=new Record().set("member_id",member_id).set("question",question)
                .set("create_at", new java.util.Date().getTime() / 1000);
        boolean issuccess=Db.save("qht_feedback",feedback);

        if(issuccess){
            model.setData(new MemberIdModel(Integer.parseInt(String.valueOf(member_id))));
        }else{

            model.setError(ErrorCode.SYSTEM_ERROR);
        }




    }

}
