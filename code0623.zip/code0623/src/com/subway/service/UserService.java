package com.subway.service;

import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.subway.util.MD5;
import com.subway.util.SaltGenerate;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * Created by thy on 17-4-25.
 */
public class UserService {
    private static final transient Logger log = LogManager.getLogger(UserService.class);
    public static UserService me=new UserService();

    public int register(String cellPhone,String password){
        Record theUser= Db.findFirst("select * from qht_member where cellphone=?",cellPhone);
        if(theUser!=null){
            return -2;
        }
        String salt=SaltGenerate.generate();
        Record user=new Record().set("cellphone", cellPhone).set("salt", salt).set("password", MD5.getMD5(password+salt)).set("create_at",new java.util.Date().getTime()/1000);
        boolean isSuccess=Db.save("qht_member", user);//可以指定主键,插入的时候自动寻找主键（id与主键对应），update的时候不能获取到id的值
        if(!isSuccess){
            return -1;
        }

        return Integer.parseInt(String.valueOf(user.getLong("id")));//id是默认主键
    }

    public int login(String cellPhone,String password){
        Record user= Db.findFirst("select * from qht_member where cellphone=?",cellPhone);
        if(user==null||!user.getStr("password").equals(MD5.getMD5(password+user.getStr("salt")))){
            log.warn(cellPhone+"密码错误");
            return -1;
        }
        user.set("update_at",new java.util.Date().getTime()/1000);
        Db.update("qht_member","member_id",user);
        return Integer.parseInt(String.valueOf(user.getLong("member_id")));
    }
    public int loginBySms(String cellPhone){
        Record user= Db.findFirst("select * from qht_member where cellphone=?",cellPhone);
        if(user==null){
            return -1;
        }
        user.set("update_at",new java.util.Date().getTime()/1000);
        Db.update("qht_member","member_id",user);//返回影响行数，位
        return Integer.parseInt(String.valueOf(user.getLong("member_id")));
    }

    public int changePassword(String cellPhone, String password, String new_password){
        Record user= Db.findFirst("select * from qht_member where cellphone=?",cellPhone);
        String salt=user.getStr("salt");
        if(user==null||!user.getStr("password").equals( MD5.getMD5(password+salt))){
            log.warn(cellPhone+"修改密码错误");
            return -1;
        }
        boolean isUpdated=Db.update("qht_member","member_id",user.set("password",MD5.getMD5(new_password+salt)).set("update_at",new java.util.Date().getTime()/1000));
        if(isUpdated){

            return  Integer.parseInt(String.valueOf(user.getLong("member_id")));
        }else{
            return -1;

        }
    }


    public int changePasswordBySms(String cellPhone, String new_password){
        Record user= Db.findFirst("select * from qht_member where cellphone=?",cellPhone);
        if(user!=null){
            return -1;
        }
        String salt=user.getStr("salt");
        boolean isUpdated=Db.update("qht_member","member_id",user.set("password",MD5.getMD5(new_password+salt)).set("update_at",new java.util.Date().getTime()/1000));
        if(isUpdated){

            return  Integer.parseInt(String.valueOf(user.getLong("member_id")));
        }else{
            return -1;

        }
    }






}
