package com.subway.service;

import com.jfinal.aop.Before;
import com.jfinal.aop.Enhancer;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.subway.interceptor.ServiceErrorInterceptor;
import com.subway.model.BaseModel;
import com.subway.model.dataModel.ChargeModel;
import com.subway.model.dataModel.ChargeOrderModel;
import com.subway.model.dataModel.PrepayModel;
import com.subway.wx_pay.model.request.ReqOrderModel;
import com.subway.wx_pay.util.*;
import okhttp3.*;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by thy on 17-4-27.
 */
public class ChargeService {
    private static final transient Logger log = LogManager.getLogger(ChargeService.class);
    public static ChargeService me = new ChargeService();

    public void charge(String member_id, int fee,String order_no, String bodyStr,String ip,String openID,String payType,BaseModel<PrepayModel> model) {
//充值处理，此处应添加充值订单表，先生成充值订单，然后在入表（只有完成充值的才写入）
// 或者先写入，充值成功后再标记
//        System.out.println("==="+order_no.length());
        Map<String,String> map=wxpay(bodyStr,fee,order_no,ip,openID);
        String prePayId=map.get("prepay_id");
        map.remove("prepay_id");
        int status = 0;
        Record charge = new Record().set("member_id", Integer.parseInt(member_id)).
                set("fee", new BigDecimal(""+fee)).set("prepay_id",prePayId).
                set("order_no", order_no).set("status", status).set("pay_type", payType).set("create_at", new java.util.Date().getTime() / 1000);
        boolean isSuccess = Db.save("qht_charge_order", charge);
        PrepayModel chargeModel = new PrepayModel();
        if (isSuccess) {
            chargeModel.setMember_id(charge.getInt("member_id"));
            chargeModel.setPrepay(map);
            log.info("订单号："+order_no+",充值金额"+fee+"分，充值中...");
        }

        model.setData(chargeModel);


    }

    public void updateCharge(String member_id, BigDecimal fee, String prepay,String order_no, String payment,BaseModel<ChargeModel> model) {
        int status = 1;
        int count=Db.update("update qht_charge_order set status=? where order_no=?",status,order_no);
        ChargeModel chargeModel = new ChargeModel();
        if (count==1) {
            chargeModel.setMember_id(Integer.parseInt(member_id));
            chargeModel.setRecharge_order_id(order_no);
            log.info("订单号："+order_no+",充值金额"+fee+"分，充值完成");
        }

        model.setData(chargeModel);


    }


    public void queryCharge(String member_id, String order_no, BaseModel<ChargeOrderModel> model) {
        Record order = Db.findFirst("select * from qht_charge_order where order_no=?", order_no);

//        ChargeOrderModel chargeOrderModel = new ChargeOrderModel();
//        if (order!=null) {
//
//            chargeOrderModel.setMember_id(Integer.parseInt(String.valueOf(order.getLong("member_id"))));
//            chargeOrderModel.setEnd_at(order.getInt("end_at"));
//            chargeOrderModel.setOrder_no(order_no);
//            chargeOrderModel.setPayment(order.getStr("payment"));
//            chargeOrderModel.setStatus(order.getStr("status"));
//            chargeOrderModel.setFee(order.getBigDecimal("fee").doubleValue());
//        }else{
//            //添加一个方法，参数设为model，使用拦截器处理，或者根据返回来判断后续处理
//        }

//        model.setData(chargeOrderModel);

//对自身增强后再调用
        ChargeService service = Enhancer.enhance(ChargeService.class);
        service.func(order, model);
    }

    @Before(ServiceErrorInterceptor.class)
    public void func(Record order, BaseModel model) {
        ChargeOrderModel chargeOrderModel = new ChargeOrderModel();
        chargeOrderModel.setMember_id(order.getInt("member_id"));
        chargeOrderModel.setEnd_at(order.getInt("end_at"));
        chargeOrderModel.setPayment(order.getStr("payment"));
        chargeOrderModel.setStatus(order.getStr("status"));
        chargeOrderModel.setFee(order.getBigDecimal("fee").doubleValue());
        model.setData(chargeOrderModel);

    }




    public Map<String,String> wxpay(String bodyStr,int fee,String orderNo,String ip,String openID) {
        String url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
        ReqOrderModel model = new ReqOrderModel();

        model.setNonce_str(RandomStringGenerator.getRandomStringByLength(30));
        model.setBody(bodyStr);
        model.setOut_trade_no(orderNo);
        model.setTotal_fee(fee);
        model.setSpbill_create_ip(ip);
        model.setNotify_url(WxConstant.WX_NOTIFY);
        model.setOpenid(openID);

        try {
            model.setSign(Signature.getSign(model));
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        System.out.println("" + model.toMap());

        String requestBody = XMLBeanUtils.map2XmlString(model.toMap());
        String responseXml = "";
        MediaType XML = MediaType.parse("application/xml; charset=utf-8");
        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(XML, requestBody);
        System.out.println("" + requestBody);

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                responseXml = response.body().string();
                System.out.println(responseXml);
                try {
                    Map<String, Object> map = XMLParser.getMapFromXML(responseXml);
                    if (map.get("return_code").toString().equals("SUCCESS") && map.get("result_code").toString().equals("SUCCESS")) {
                        if (Signature.checkIsSignValidFromResponseString(responseXml)) {

                            Map<String,String> responseMap=new HashMap<String,String>();
                            responseMap.put("appId", WxConstant.APPID);
                            responseMap.put("timeStamp", ""+new java.util.Date().getTime() / 1000);
                            responseMap.put("nonceStr", RandomStringGenerator.getRandomStringByLength(30));
                            responseMap.put("signType", WxConstant.MD5);
                            responseMap.put("package", "prepay_id="+map.get("prepay_id"));


                            try {
                                responseMap.put("paySign", Signature.getSign(responseMap));
                            } catch (IllegalAccessException e) {
                                e.printStackTrace();


                            }

                            responseMap.put("prepay_id", ""+map.get("prepay_id"));
                            return responseMap;

                        }
                    }
                } catch (ParserConfigurationException e) {
                    e.printStackTrace();
                } catch (SAXException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;


    }
}
