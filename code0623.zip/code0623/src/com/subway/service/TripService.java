package com.subway.service;

import com.google.gson.Gson;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.subway.config.constant.ErrorCode;
import com.subway.model.BaseModel;
import com.subway.model.dataModel.QueryTripOrderModel;
import com.subway.model.dataModel.QueryTripOrderOverModel;
import com.subway.model.dataModel.TripOrderModel;
import com.subway.model.requestModel.TravelerModel;
import com.subway.util.OrderNoGenerate;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by thy on 17-4-27.
 */
public class TripService {
    private static final transient Logger log = LogManager.getLogger(TripService.class);
    public static TripService me = new TripService();


//    订单号 订单id区分开
    public void tripOrder(String member_id, String passengers, String start, BaseModel<TripOrderModel> model) {

        String order_no = OrderNoGenerate.generate("3502");

        Gson gson = new Gson();
        List<TravelerModel.Passenger> travelerModels= gson.fromJson(passengers,TravelerModel.class).getData_list();

        SimpleDateFormat dateformat1=new SimpleDateFormat("yyyyMM");
        SimpleDateFormat dateformat2=new SimpleDateFormat("dd");
        SimpleDateFormat dateformat3=new SimpleDateFormat("HH");

        String year_month=dateformat1.format(new Date());
        String day=dateformat2.format(new Date());
        String hour=dateformat3.format(new Date());
//判断余额是否充足，扣除余额，事务操作，扣钱和写入
        Record userDetail = Db.findFirst("select * from qht_member_info where member_id=?", member_id);
        BigDecimal fee=new BigDecimal("0.00");
        BigDecimal balance=userDetail.getBigDecimal("balance");
        if(balance.subtract(fee).doubleValue()<0){
            //余额不足提示
            model.setError(ErrorCode.NOT_ENOUGH_MONEY);
        }





        Record tripOrderOver = new Record().set("member_id", Integer.parseInt(String.valueOf(member_id))).
                set("passengers", passengers).set("order_no", order_no).set("start", Integer.parseInt(start)).
                set("start_station_id","").set("end_station_id", "").
                set("ride_time", "").set("departure_time","").set("price", "").set("total_fee", "").
                set("status",1).set("day",day).set("hour",hour).set("year_month",year_month).
                set("create_at", new java.util.Date().getTime() / 1000);
        boolean isSuccess = Db.save("qht_trip_order", tripOrderOver);
        if(isSuccess){

            int subOrder=1;
            for(TravelerModel.Passenger passenger:travelerModels){

                Record tripOrderDetail=new Record().set("sub_order_no", OrderNoGenerate.generate("003502")+subOrder).
                        set("identity_infor_id", passenger.getIdentity_infor_id()).set("real_name", passenger.getName()).set("trip_order_id", tripOrderOver.getLong("trip_order_id"))
                        .set("create_at", new java.util.Date().getTime() / 1000);
                Db.save("qht_trip_order_detail",tripOrderDetail);
                ++subOrder;
            }
        }




        TripOrderModel chargeModel = new TripOrderModel();
        if (isSuccess) {

            chargeModel.setMember_id(Integer.parseInt(String.valueOf(tripOrderOver.getLong("member_id"))));
            chargeModel.setOrder_no(order_no);
            log.info("乘车订单号"+order_no+"下单");
        }

        model.setData(chargeModel);



    }

    /**
     *
     *
     *
     * @param member_id
     * @param order_no
     * @param model
     */
    public void tripOrderOver(String member_id, String order_no, BaseModel<TripOrderModel> model) {



       int updated=Db.update("update qht_tripping_order set delete_at=? where sub_order_no=?", System.currentTimeMillis() / 1000, order_no);

        TripOrderModel chargeModel = new TripOrderModel();
        if (updated==1) {

            chargeModel.setMember_id(Integer.parseInt(member_id));
            chargeModel.setOrder_no(order_no);
            log.info("乘车订单号"+order_no+"下单完成");
        }

        model.setData(chargeModel);


    }


    public void queryTripOrder(String member_id, String order_no, BaseModel<QueryTripOrderModel> model) {

        Record tripOrder = Db.findFirst("select * from qht_trip_order where order_no=?", order_no);



        QueryTripOrderModel chargeModel = new QueryTripOrderModel();
        if (tripOrder!=null) {

            chargeModel.setMember_id(Integer.parseInt(String.valueOf(tripOrder.getLong("member_id"))));
            chargeModel.setOrder_no(order_no);
            chargeModel.setPassengers(tripOrder.getStr("passengers"));
            chargeModel.setTotal_fee(tripOrder.getBigDecimal("total_fee").doubleValue());
            chargeModel.setDeparture_time(tripOrder.getInt("departure_time"));
            chargeModel.setEnd_station_id(tripOrder.getInt("end_station_id"));
            chargeModel.setRide_time(tripOrder.getInt("ride_time"));
            chargeModel.setStart_station_id(tripOrder.getInt("start_station_id"));
            chargeModel.setStatus(tripOrder.getInt("staus"));
        }

        model.setData(chargeModel);


    }

    //乘车订单详情查询
    public void queryTripOrderOver(String member_id, String order_no, BaseModel<QueryTripOrderOverModel> model) {

        Record charge = Db.findFirst("select * from qht_trip_order_detail where sub_order_no=?", order_no);
        QueryTripOrderOverModel chargeModel = new QueryTripOrderOverModel();
        if (charge!=null) {

            chargeModel.setMember_id(Integer.parseInt(String.valueOf(charge.getLong("member_id"))));
            chargeModel.setOrder_no(order_no);
            chargeModel.setIdentity_infor_id(charge.getInt("identity_infor_id"));
            chargeModel.setReal_name(charge.getStr("real_name"));
        }

        model.setData(chargeModel);


    }

    private static final ThreadLocal<DateFormat> df = new ThreadLocal<DateFormat>() {
        @ Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy-MM-dd");
        }
    };
}
